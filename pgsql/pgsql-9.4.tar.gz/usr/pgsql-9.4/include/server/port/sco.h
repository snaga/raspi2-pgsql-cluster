/*
 * src/include/port/sco.h
 *
 * see src/backend/libpq/pqcomm.c */
#define SCO_ACCEPT_BUG

#define USE_UNIVEL_CC
